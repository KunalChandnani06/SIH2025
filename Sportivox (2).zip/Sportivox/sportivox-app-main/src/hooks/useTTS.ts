import { useSpeechSynthesis } from 'react-speech-kit';

export const useTTS = () => {
  const { speak, cancel, speaking, voices } = useSpeechSynthesis();

  const speakText = (text: string, language = 'en-US') => {
    cancel(); // Stop any current speech
    
    // Find voice for the language
    const voice = voices.find(v => v.lang.startsWith(language)) || voices[0];
    
    speak({
      text,
      voice,
      rate: 0.8,
      pitch: 1.1
    });
  };

  const stopSpeaking = () => {
    cancel();
  };

  return {
    speakText,
    stopSpeaking,
    speaking,
    voices
  };
};