import { useEffect, useState } from 'react';
import { useAppContext } from '../context/AppContext';

export const useLiveUpdates = () => {
  const { state, dispatch } = useAppContext();
  const [isLive, setIsLive] = useState(false);

  useEffect(() => {
    if (!isLive) return;

    // Simulate live leaderboard updates every 15 seconds
    const interval = setInterval(() => {
      // Randomly update some user stats (simulate other users taking tests)
      const randomUser = state.users[Math.floor(Math.random() * state.users.length)];
      if (randomUser && randomUser.id !== state.user?.id) {
        const pointsIncrease = Math.floor(Math.random() * 50) + 10;
        const updatedUser = {
          ...randomUser,
          totalPoints: randomUser.totalPoints + pointsIncrease,
          streak: Math.min(randomUser.streak + 1, 30)
        };
        
        dispatch({ type: 'UPDATE_USER', payload: updatedUser });
        
        // Show a toast notification for demo purposes
        if (Math.random() > 0.7) { // 30% chance to show notification
          // You could add a toast here if needed
        }
      }
    }, 15000);

    return () => clearInterval(interval);
  }, [isLive, state.users, state.user?.id, dispatch]);

  const toggleLiveUpdates = () => {
    setIsLive(!isLive);
  };

  return {
    isLive,
    toggleLiveUpdates
  };
};