export interface User {
  id: string;
  email: string;
  name: string;
  age: number;
  gender: 'male' | 'female' | 'other';
  sport: string;
  location: string;
  role: 'athlete' | 'admin';
  createdAt: string;
  streak: number;
  totalPoints: number;
  badges: Badge[];
}

export interface Badge {
  id: string;
  name: string;
  description: string;
  icon: string;
  earnedAt: string;
  category: 'fitness' | 'achievement' | 'streak' | 'participation';
}

export interface TestResult {
  id: string;
  userId: string;
  testType: 'height_weight' | 'vertical_jump' | 'sit_ups' | 'shuttle_run' | 'endurance_run';
  data: Record<string, any>;
  score: number;
  analysis: TestAnalysis;
  submittedAt: string;
  flagged: boolean;
  flagReason?: string;
}

export interface TestAnalysis {
  score: number;
  grade: 'excellent' | 'good' | 'average' | 'needs_improvement';
  feedback: string;
  improvements: string[];
  benchmark: {
    percentile: number;
    ageGroup: string;
    gender: string;
  };
}

export interface Challenge {
  id: string;
  title: string;
  description: string;
  type: 'daily' | 'weekly' | 'monthly';
  target: number;
  current: number;
  reward: {
    points: number;
    badge?: Badge;
  };
  expiresAt: string;
  completed: boolean;
}

export interface LeaderboardEntry {
  userId: string;
  name: string;
  totalPoints: number;
  rank: number;
  sport: string;
  location: string;
  badges: number;
  streak: number;
}