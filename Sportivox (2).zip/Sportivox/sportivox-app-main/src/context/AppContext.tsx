import React, { createContext, useContext, useReducer, ReactNode, useEffect } from 'react';
import { User, TestResult, Challenge } from '../types';
import { mockUsers, mockTestResults, mockChallenges, STORAGE_KEYS, initializeMockData } from '../data/mockData';

interface AppState {
  user: User | null;
  users: User[];
  testResults: TestResult[];
  challenges: Challenge[];
  loading: boolean;
  language: string;
}

type AppAction = 
  | { type: 'SET_USER'; payload: User | null }
  | { type: 'SET_USERS'; payload: User[] }
  | { type: 'ADD_TEST_RESULT'; payload: TestResult }
  | { type: 'UPDATE_CHALLENGES'; payload: Challenge[] }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_LANGUAGE'; payload: string }
  | { type: 'UPDATE_USER'; payload: User };

const initialState: AppState = {
  user: null,
  users: [],
  testResults: [],
  challenges: [],
  loading: false,
  language: 'en'
};

const AppContext = createContext<{
  state: AppState;
  dispatch: React.Dispatch<AppAction>;
  login: (email: string, password: string) => Promise<boolean>;
  register: (userData: Omit<User, 'id' | 'createdAt' | 'totalPoints' | 'badges' | 'streak'> & { password: string }) => Promise<boolean>;
  logout: () => void;
  submitTestResult: (result: Omit<TestResult, 'id' | 'submittedAt'>) => void;
  updateProfile: (userData: Partial<User>) => void;
  analyzeVideo: (testType: string, data: any) => Promise<any>;
} | undefined>(undefined);

function appReducer(state: AppState, action: AppAction): AppState {
  switch (action.type) {
    case 'SET_USER':
      return { ...state, user: action.payload };
    case 'SET_USERS':
      return { ...state, users: action.payload };
    case 'ADD_TEST_RESULT':
      return { ...state, testResults: [...state.testResults, action.payload] };
    case 'UPDATE_CHALLENGES':
      return { ...state, challenges: action.payload };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_LANGUAGE':
      return { ...state, language: action.payload };
    case 'UPDATE_USER':
      return { 
        ...state, 
        user: state.user?.id === action.payload.id ? action.payload : state.user,
        users: state.users.map(u => u.id === action.payload.id ? action.payload : u)
      };
    default:
      return state;
  }
}

export function AppProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(appReducer, initialState);

  useEffect(() => {
    initializeMockData();
    
    // Load data from localStorage
    const savedUser = localStorage.getItem(STORAGE_KEYS.USER);
    const savedUsers = localStorage.getItem(STORAGE_KEYS.USERS);
    const savedTestResults = localStorage.getItem(STORAGE_KEYS.TEST_RESULTS);
    const savedChallenges = localStorage.getItem(STORAGE_KEYS.CHALLENGES);
    const savedLanguage = localStorage.getItem(STORAGE_KEYS.LANGUAGE);

    if (savedUser) {
      dispatch({ type: 'SET_USER', payload: JSON.parse(savedUser) });
    }
    
    dispatch({ type: 'SET_USERS', payload: savedUsers ? JSON.parse(savedUsers) : mockUsers });
    dispatch({ type: 'ADD_TEST_RESULT', payload: savedTestResults ? JSON.parse(savedTestResults)[0] : mockTestResults[0] });
    dispatch({ type: 'UPDATE_CHALLENGES', payload: savedChallenges ? JSON.parse(savedChallenges) : mockChallenges });
    dispatch({ type: 'SET_LANGUAGE', payload: savedLanguage || 'en' });
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const user = state.users.find(u => u.email === email);
    if (user) {
      dispatch({ type: 'SET_USER', payload: user });
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(user));
      dispatch({ type: 'SET_LOADING', payload: false });
      return true;
    }
    
    dispatch({ type: 'SET_LOADING', payload: false });
    return false;
  };

  const register = async (userData: Omit<User, 'id' | 'createdAt' | 'totalPoints' | 'badges' | 'streak'> & { password: string }): Promise<boolean> => {
    dispatch({ type: 'SET_LOADING', payload: true });
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const newUser: User = {
      ...userData,
      id: Date.now().toString(),
      createdAt: new Date().toISOString(),
      totalPoints: 0,
      badges: [],
      streak: 0
    };
    
    const updatedUsers = [...state.users, newUser];
    dispatch({ type: 'SET_USERS', payload: updatedUsers });
    dispatch({ type: 'SET_USER', payload: newUser });
    
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(updatedUsers));
    localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(newUser));
    
    dispatch({ type: 'SET_LOADING', payload: false });
    return true;
  };

  const logout = () => {
    dispatch({ type: 'SET_USER', payload: null });
    localStorage.removeItem(STORAGE_KEYS.USER);
  };

  const submitTestResult = (result: Omit<TestResult, 'id' | 'submittedAt'>) => {
    const newResult: TestResult = {
      ...result,
      id: Date.now().toString(),
      submittedAt: new Date().toISOString()
    };
    
    dispatch({ type: 'ADD_TEST_RESULT', payload: newResult });
    
    // Update user points and streak
    if (state.user) {
      const updatedUser = {
        ...state.user,
        totalPoints: state.user.totalPoints + result.score,
        streak: state.user.streak + 1
      };
      dispatch({ type: 'UPDATE_USER', payload: updatedUser });
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));
    }
    
    // Save to localStorage
    const allResults = [...state.testResults, newResult];
    localStorage.setItem(STORAGE_KEYS.TEST_RESULTS, JSON.stringify(allResults));
  };

  const updateProfile = (userData: Partial<User>) => {
    if (state.user) {
      const updatedUser = { ...state.user, ...userData };
      dispatch({ type: 'UPDATE_USER', payload: updatedUser });
      localStorage.setItem(STORAGE_KEYS.USER, JSON.stringify(updatedUser));
    }
  };

  // Mock AI analysis function
  const analyzeVideo = async (testType: string, data: any): Promise<any> => {
    // Simulate processing time
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Mock analysis based on test type
    switch (testType) {
      case 'vertical_jump':
        return {
          height: Math.floor(Math.random() * 30) + 50, // 50-80cm
          technique_score: Math.floor(Math.random() * 20) + 80, // 80-100%
          consistency: Math.floor(Math.random() * 15) + 85 // 85-100%
        };
      case 'sit_ups':
        return {
          count: Math.floor(Math.random() * 20) + 35, // 35-55 reps
          form_score: Math.floor(Math.random() * 15) + 85, // 85-100%
          pace: 'consistent'
        };
      case 'shuttle_run':
        return {
          time: (Math.random() * 2 + 8).toFixed(1), // 8.0-10.0 seconds
          agility_score: Math.floor(Math.random() * 20) + 80, // 80-100%
          turning_technique: 'good'
        };
      default:
        return { score: Math.floor(Math.random() * 30) + 70 };
    }
  };

  return (
    <AppContext.Provider value={{
      state,
      dispatch,
      login,
      register,
      logout,
      submitTestResult,
      updateProfile,
      analyzeVideo
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (context === undefined) {
    throw new Error('useAppContext must be used within an AppProvider');
  }
  return context;
}