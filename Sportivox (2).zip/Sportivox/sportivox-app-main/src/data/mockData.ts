import { User, Badge, TestResult, Challenge, LeaderboardEntry } from '../types';

// Mock Users
export const mockUsers: User[] = [
  {
    id: '1',
    email: 'admin@sportassess.com',
    name: 'Admin User',
    age: 30,
    gender: 'male',
    sport: 'General',
    location: 'Mumbai',
    role: 'admin',
    createdAt: '2024-01-01T00:00:00Z',
    streak: 0,
    totalPoints: 0,
    badges: []
  },
  {
    id: '2',
    email: 'rahul@example.com',
    name: 'Rahul Sharma',
    age: 22,
    gender: 'male',
    sport: 'Cricket',
    location: 'Delhi',
    role: 'athlete',
    createdAt: '2024-09-01T00:00:00Z',
    streak: 15,
    totalPoints: 2450,
    badges: []
  },
  {
    id: '3',
    email: 'priya@example.com',
    name: 'Priya Patel',
    age: 19,
    gender: 'female',
    sport: 'Basketball',
    location: 'Ahmedabad',
    role: 'athlete',
    createdAt: '2024-09-05T00:00:00Z',
    streak: 8,
    totalPoints: 1890,
    badges: []
  },
  {
    id: '4',
    email: 'arjun@example.com',
    name: 'Arjun Kumar',
    age: 24,
    gender: 'male',
    sport: 'Football',
    location: 'Bangalore',
    role: 'athlete',
    createdAt: '2024-08-15T00:00:00Z',
    streak: 22,
    totalPoints: 3200,
    badges: []
  }
];

// Mock Badges
export const mockBadges: Badge[] = [
  {
    id: 'first_test',
    name: 'First Test',
    description: 'Completed your first fitness test',
    icon: '🎯',
    earnedAt: '2024-09-20T00:00:00Z',
    category: 'achievement'
  },
  {
    id: 'streak_7',
    name: '7 Day Streak',
    description: 'Maintained a 7-day training streak',
    icon: '🔥',
    earnedAt: '2024-09-22T00:00:00Z',
    category: 'streak'
  },
  {
    id: 'jump_master',
    name: 'Jump Master',
    description: 'Excellent vertical jump performance',
    icon: '🦘',
    earnedAt: '2024-09-21T00:00:00Z',
    category: 'fitness'
  },
  {
    id: 'endurance_champion',
    name: 'Endurance Champion',
    description: 'Outstanding endurance run performance',
    icon: '🏃‍♂️',
    earnedAt: '2024-09-23T00:00:00Z',
    category: 'fitness'
  }
];

// Mock Test Results
export const mockTestResults: TestResult[] = [
  {
    id: 'tr1',
    userId: '2',
    testType: 'vertical_jump',
    data: { height: 68, attempts: 3 },
    score: 85,
    analysis: {
      score: 85,
      grade: 'excellent',
      feedback: 'Outstanding vertical jump! Your explosive power is excellent.',
      improvements: ['Work on landing technique', 'Increase core strength'],
      benchmark: { percentile: 90, ageGroup: '20-25', gender: 'male' }
    },
    submittedAt: '2024-09-20T10:30:00Z',
    flagged: false
  },
  {
    id: 'tr2',
    userId: '3',
    testType: 'sit_ups',
    data: { count: 45, duration: 60 },
    score: 78,
    analysis: {
      score: 78,
      grade: 'good',
      feedback: 'Good core strength! Keep up the consistent training.',
      improvements: ['Improve form', 'Increase pace gradually'],
      benchmark: { percentile: 75, ageGroup: '18-22', gender: 'female' }
    },
    submittedAt: '2024-09-19T15:45:00Z',
    flagged: false
  },
  {
    id: 'tr3',
    userId: '4',
    testType: 'shuttle_run',
    data: { time: 9.2, distance: 20 },
    score: 92,
    analysis: {
      score: 92,
      grade: 'excellent',
      feedback: 'Exceptional agility and speed! Your shuttle run time is impressive.',
      improvements: ['Maintain consistency', 'Focus on acceleration'],
      benchmark: { percentile: 95, ageGroup: '22-26', gender: 'male' }
    },
    submittedAt: '2024-09-18T09:15:00Z',
    flagged: false
  }
];

// Mock Challenges
export const mockChallenges: Challenge[] = [
  {
    id: 'daily_1',
    title: 'Daily Jump Challenge',
    description: 'Complete 3 vertical jump tests today',
    type: 'daily',
    target: 3,
    current: 1,
    reward: { points: 50 },
    expiresAt: '2024-09-25T23:59:59Z',
    completed: false
  },
  {
    id: 'weekly_1',
    title: 'Weekly Warrior',
    description: 'Complete 5 different fitness tests this week',
    type: 'weekly',
    target: 5,
    current: 2,
    reward: { 
      points: 200,
      badge: {
        id: 'weekly_warrior',
        name: 'Weekly Warrior',
        description: 'Completed 5 tests in a week',
        icon: '⚡',
        earnedAt: '',
        category: 'achievement'
      }
    },
    expiresAt: '2024-09-29T23:59:59Z',
    completed: false
  },
  {
    id: 'monthly_1',
    title: 'Monthly Marathon',
    description: 'Accumulate 1000 points this month',
    type: 'monthly',
    target: 1000,
    current: 450,
    reward: { 
      points: 500,
      badge: {
        id: 'monthly_marathon',
        name: 'Monthly Marathon',
        description: 'Earned 1000+ points in a month',
        icon: '🏆',
        earnedAt: '',
        category: 'achievement'
      }
    },
    expiresAt: '2024-09-30T23:59:59Z',
    completed: false
  }
];

// Mock Leaderboard
export const mockLeaderboard: LeaderboardEntry[] = [
  {
    userId: '4',
    name: 'Arjun Kumar',
    totalPoints: 3200,
    rank: 1,
    sport: 'Football',
    location: 'Bangalore',
    badges: 8,
    streak: 22
  },
  {
    userId: '2',
    name: 'Rahul Sharma',
    totalPoints: 2450,
    rank: 2,
    sport: 'Cricket',
    location: 'Delhi',
    badges: 6,
    streak: 15
  },
  {
    userId: '3',
    name: 'Priya Patel',
    totalPoints: 1890,
    rank: 3,
    sport: 'Basketball',
    location: 'Ahmedabad',
    badges: 4,
    streak: 8
  }
];

// Mock localStorage keys
export const STORAGE_KEYS = {
  USER: 'sports_assess_user',
  USERS: 'sports_assess_users',
  TEST_RESULTS: 'sports_assess_test_results',
  CHALLENGES: 'sports_assess_challenges',
  LANGUAGE: 'sports_assess_language'
};

// Initialize mock data in localStorage
export const initializeMockData = () => {
  if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
    localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(mockUsers));
  }
  if (!localStorage.getItem(STORAGE_KEYS.TEST_RESULTS)) {
    localStorage.setItem(STORAGE_KEYS.TEST_RESULTS, JSON.stringify(mockTestResults));
  }
  if (!localStorage.getItem(STORAGE_KEYS.CHALLENGES)) {
    localStorage.setItem(STORAGE_KEYS.CHALLENGES, JSON.stringify(mockChallenges));
  }
};