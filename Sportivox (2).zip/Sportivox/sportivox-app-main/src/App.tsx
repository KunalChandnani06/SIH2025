import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useAppContext } from './context/AppContext';
import { AppProvider } from './context/AppContext';
import './i18n';
import Auth from './pages/Auth';
import Dashboard from './pages/Dashboard';
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AppProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AppRoutes />
        </BrowserRouter>
      </TooltipProvider>
    </AppProvider>
  </QueryClientProvider>
);

const AppRoutes = () => {
  const { state } = useAppContext();
  
  return (
    <Routes>
      <Route path="/" element={state.user ? <Dashboard /> : <Auth />} />
      <Route path="*" element={<NotFound />} />
    </Routes>
  );
};

export default App;
