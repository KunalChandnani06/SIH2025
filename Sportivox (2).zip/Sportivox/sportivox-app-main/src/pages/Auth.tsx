import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAppContext } from '@/context/AppContext';
import { Trophy, Activity, Target } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const Auth = () => {
  const { t } = useTranslation();
  const { login, register, state } = useAppContext();
  const [isLogin, setIsLogin] = useState(true);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    age: '',
    gender: '',
    sport: '',
    location: ''
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (isLogin) {
        const success = await login(formData.email, formData.password);
        if (success) {
          toast({
            title: "Login Successful!",
            description: "Welcome back to SportAssess",
          });
        } else {
          toast({
            title: "Login Failed",
            description: "Invalid credentials. Try admin@sportassess.com with any password.",
            variant: "destructive"
          });
        }
      } else {
        const success = await register({
          email: formData.email,
          password: formData.password,
          name: formData.name,
          age: parseInt(formData.age),
          gender: formData.gender as 'male' | 'female' | 'other',
          sport: formData.sport,
          location: formData.location,
          role: 'athlete'
        });
        
        if (success) {
          toast({
            title: "Registration Successful!",
            description: "Welcome to SportAssess! Let's start your fitness journey.",
          });
        }
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Something went wrong. Please try again.",
        variant: "destructive"
      });
    }
  };

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen gradient-hero flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="gradient-card w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-4 shadow-primary animate-bounce-in">
            <Trophy className="w-10 h-10 text-primary" />
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">SportAssess</h1>
          <p className="text-white/80">AI-Powered Sports Talent Assessment</p>
        </div>

        {/* Auth Card */}
        <Card className="gradient-card border-white/20 shadow-card animate-slide-up">
          <CardHeader className="text-center">
            <CardTitle className="text-2xl">{isLogin ? t('login') : t('register')}</CardTitle>
            <CardDescription>
              {isLogin 
                ? 'Enter your credentials to access your dashboard'
                : 'Create your account to start your fitness journey'
              }
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-4">
              {!isLogin && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="name">{t('name')}</Label>
                    <Input
                      id="name"
                      type="text"
                      value={formData.name}
                      onChange={(e) => handleInputChange('name', e.target.value)}
                      required={!isLogin}
                      className="transition-smooth focus:shadow-primary"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label htmlFor="age">{t('age')}</Label>
                      <Input
                        id="age"
                        type="number"
                        min="13"
                        max="100"
                        value={formData.age}
                        onChange={(e) => handleInputChange('age', e.target.value)}
                        required={!isLogin}
                      />
                    </div>
                    
                    <div className="space-y-2">
                      <Label>{t('gender')}</Label>
                      <Select value={formData.gender} onValueChange={(value) => handleInputChange('gender', value)}>
                        <SelectTrigger>
                          <SelectValue placeholder="Select gender" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="male">Male</SelectItem>
                          <SelectItem value="female">Female</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>{t('sport')}</Label>
                    <Select value={formData.sport} onValueChange={(value) => handleInputChange('sport', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select primary sport" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cricket">Cricket</SelectItem>
                        <SelectItem value="football">Football</SelectItem>
                        <SelectItem value="basketball">Basketball</SelectItem>
                        <SelectItem value="tennis">Tennis</SelectItem>
                        <SelectItem value="athletics">Athletics</SelectItem>
                        <SelectItem value="badminton">Badminton</SelectItem>
                        <SelectItem value="swimming">Swimming</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="location">{t('location')}</Label>
                    <Input
                      id="location"
                      type="text"
                      value={formData.location}
                      onChange={(e) => handleInputChange('location', e.target.value)}
                      placeholder="City, State"
                      required={!isLogin}
                    />
                  </div>
                </>
              )}

              <div className="space-y-2">
                <Label htmlFor="email">{t('email')}</Label>
                <Input
                  id="email"
                  type="email"
                  value={formData.email}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  required
                  placeholder="admin@sportassess.com"
                  className="transition-smooth focus:shadow-primary"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">{t('password')}</Label>
                <Input
                  id="password"
                  type="password"
                  value={formData.password}
                  onChange={(e) => handleInputChange('password', e.target.value)}
                  required
                  className="transition-smooth focus:shadow-primary"
                />
              </div>

              <Button 
                type="submit" 
                className="w-full"
                variant="hero"
                disabled={state.loading}
              >
                {state.loading ? t('loading') : (isLogin ? t('login') : t('register'))}
              </Button>
            </form>

            <div className="mt-6 text-center">
              <Button
                variant="ghost"
                onClick={() => setIsLogin(!isLogin)}
                className="text-sm"
              >
                {isLogin 
                  ? "Don't have an account? Register here" 
                  : "Already have an account? Login here"
                }
              </Button>
            </div>

            {/* Demo Account Info */}
            {isLogin && (
              <div className="mt-4 p-3 bg-primary/10 rounded-lg border border-primary/20">
                <p className="text-xs text-muted-foreground">
                  <strong>Demo Accounts:</strong><br />
                  Admin: admin@sportassess.com<br />
                  Athlete: rahul@example.com<br />
                  Password: any
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Features */}
        <div className="mt-8 grid grid-cols-3 gap-4">
          <div className="text-center">
            <Activity className="w-8 h-8 text-white mx-auto mb-2" />
            <p className="text-white/80 text-sm">Fitness Tests</p>
          </div>
          <div className="text-center">
            <Trophy className="w-8 h-8 text-white mx-auto mb-2" />
            <p className="text-white/80 text-sm">Leaderboards</p>
          </div>
          <div className="text-center">
            <Target className="w-8 h-8 text-white mx-auto mb-2" />
            <p className="text-white/80 text-sm">Challenges</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Auth;