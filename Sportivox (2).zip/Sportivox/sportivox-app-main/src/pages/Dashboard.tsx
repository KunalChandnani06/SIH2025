import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '@/context/AppContext';
import Header from '@/components/Layout/Header';
import Navigation from '@/components/Layout/Navigation';
import DashboardHome from '@/components/Dashboard/DashboardHome';
import Profile from '@/components/Dashboard/Profile';
import Tests from '@/components/Dashboard/Tests';
import Leaderboard from '@/components/Dashboard/Leaderboard';
import Challenges from '@/components/Dashboard/Challenges';
import Admin from '@/components/Dashboard/Admin';

const Dashboard = () => {
  const { t } = useTranslation();
  const { state } = useAppContext();
  const [activeTab, setActiveTab] = useState('dashboard');

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard':
        return <DashboardHome />;
      case 'profile':
        return <Profile />;
      case 'tests':
        return <Tests />;
      case 'leaderboard':
        return <Leaderboard />;
      case 'challenges':
        return <Challenges />;
      case 'admin':
        return state.user?.role === 'admin' ? <Admin /> : <DashboardHome />;
      default:
        return <DashboardHome />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <div className="flex">
        <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
        <main className="flex-1 p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default Dashboard;