import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

// Translation resources
const resources = {
  en: {
    translation: {
      // Navigation
      dashboard: 'Dashboard',
      profile: 'Profile',
      tests: 'Tests',
      leaderboard: 'Leaderboard',
      challenges: 'Challenges',
      admin: 'Admin',
      logout: 'Logout',
      
      // Auth
      login: 'Login',
      register: 'Register',
      email: 'Email',
      password: 'Password',
      name: 'Full Name',
      age: 'Age',
      gender: 'Gender',
      sport: 'Primary Sport',
      location: 'Location',
      
      // Tests
      submitTest: 'Submit Test',
      testInstructions: 'Test Instructions',
      height: 'Height (cm)',
      weight: 'Weight (kg)',
      verticalJump: 'Vertical Jump',
      sitUps: 'Sit-ups',
      shuttleRun: 'Shuttle Run',
      enduranceRun: 'Endurance Run',
      
      // Results
      results: 'Results',
      analysis: 'Analysis',
      excellent: 'Excellent',
      good: 'Good',
      average: 'Average',
      needsImprovement: 'Needs Improvement',
      
      // Gamification
      badges: 'Badges',
      streak: 'Day Streak',
      points: 'Points',
      rank: 'Rank',
      achievements: 'Achievements',
      
      // Common
      save: 'Save',
      cancel: 'Cancel',
      submit: 'Submit',
      loading: 'Loading...',
      welcome: 'Welcome',
      getStarted: 'Get Started'
    }
  },
  hi: {
    translation: {
      // Navigation
      dashboard: 'डैशबोर्ड',
      profile: 'प्रोफ़ाइल',
      tests: 'परीक्षण',
      leaderboard: 'लीडरबोर्ड',
      challenges: 'चुनौतियाँ',
      admin: 'एडमिन',
      logout: 'लॉगआउट',
      
      // Auth
      login: 'लॉगिन',
      register: 'रजिस्टर',
      email: 'ईमेल',
      password: 'पासवर्ड',
      name: 'पूरा नाम',
      age: 'उम्र',
      gender: 'लिंग',
      sport: 'मुख्य खेल',
      location: 'स्थान',
      
      // Tests
      submitTest: 'परीक्षण जमा करें',
      testInstructions: 'परीक्षण निर्देश',
      height: 'ऊंचाई (सेमी)',
      weight: 'वजन (किग्रा)',
      verticalJump: 'ऊर्ध्वाधर कूद',
      sitUps: 'सिट-अप्स',
      shuttleRun: 'शटल रन',
      enduranceRun: 'सहनशीलता दौड़',
      
      // Results
      results: 'परिणाम',
      analysis: 'विश्लेषण',
      excellent: 'उत्कृष्ट',
      good: 'अच्छा',
      average: 'औसत',
      needsImprovement: 'सुधार की आवश्यकता',
      
      // Gamification
      badges: 'बैज',
      streak: 'दिन की लकीर',
      points: 'अंक',
      rank: 'रैंक',
      achievements: 'उपलब्धियाँ',
      
      // Common
      save: 'सेव करें',
      cancel: 'रद्द करें',
      submit: 'जमा करें',
      loading: 'लोड हो रहा है...',
      welcome: 'स्वागत',
      getStarted: 'शुरू करें'
    }
  },
  ta: {
    translation: {
      // Navigation
      dashboard: 'டாஷ்போர்ட்',
      profile: 'சுயவிவரம்',
      tests: 'சோதனைகள்',
      leaderboard: 'தலைமைப் பலகை',
      challenges: 'சவால்கள்',
      admin: 'நிர்வாகி',
      logout: 'வெளியேறு',
      
      // Auth
      login: 'உள்நுழைய',
      register: 'பதிவு செய்ய',
      email: 'மின்னஞ்சல்',
      password: 'கடவுச்சொல்',
      name: 'முழு பெயர்',
      age: 'வயது',
      gender: 'பால்',
      sport: 'முதன்மை விளையாட்டு',
      location: 'இடம்',
      
      // Tests  
      submitTest: 'சோதனை சமர்ப்பிக்க',
      testInstructions: 'சோதனை வழிமுறைகள்',
      height: 'உயரம் (செமீ)',
      weight: 'எடை (கிலோ)',
      verticalJump: 'செங்குத்து தாண்டல்',
      sitUps: 'சிட்-அப்ஸ்',
      shuttleRun: 'ஷட்டில் ஓட்டம்',
      enduranceRun: 'சகிப்புத்தன்மை ஓட்டம்',
      
      // Results
      results: 'முடிவுகள்',
      analysis: 'பகுப்பாய்வு',
      excellent: 'சிறந்த',
      good: 'நல்ல',
      average: 'சராசரி',
      needsImprovement: 'மேம்பாடு தேவை',
      
      // Gamification
      badges: 'பேட்ஜ்கள்',
      streak: 'நாள் தொடர்',
      points: 'புள்ளிகள்',
      rank: 'தரம்',
      achievements: 'சாதனைகள்',
      
      // Common
      save: 'சேமி',
      cancel: 'ரத்து செய்',
      submit: 'சமர்ப்பி',
      loading: 'ஏற்றுகிறது...',
      welcome: 'வரவேற்பு',
      getStarted: 'தொடங்குங்கள்'
    }
  },
  kn: {
    translation: {
      // Navigation
      dashboard: 'ಡ್ಯಾಶ್‌ಬೋರ್ಡ್',
      profile: 'ಪ್ರೊಫೈಲ್',
      tests: 'ಪರೀಕ್ಷೆಗಳು',
      leaderboard: 'ಲೀಡರ್‌ಬೋರ್ಡ್',
      challenges: 'ಸವಾಲುಗಳು',
      admin: 'ಆಡ್ಮಿನ್',
      logout: 'ಲಾಗ್ ಔಟ್',
      
      // Auth
      login: 'ಲಾಗಿನ್',
      register: 'ನೋಂದಣಿ',
      email: 'ಇಮೇಲ್',
      password: 'ಪಾಸ್‌ವರ್ಡ್',
      name: 'ಪೂರ್ಣ ಹೆಸರು',
      age: 'ವಯಸ್ಸು',
      gender: 'ಲಿಂಗ',
      sport: 'ಮುಖ್ಯ ಕ್ರೀಡೆ',
      location: 'ಸ್ಥಳ',
      
      // Tests
      submitTest: 'ಪರೀಕ್ಷೆಯನ್ನು ಸಲ್ಲಿಸಿ',
      testInstructions: 'ಪರೀಕ್ಷೆಯ ಸೂಚನೆಗಳು',
      height: 'ಎತ್ತರ (ಸೆಮೀ)',
      weight: 'ತೂಕ (ಕೆಜಿ)',
      verticalJump: 'ಲಂಬ ಜಿಗಿತ',
      sitUps: 'ಸಿಟ್-ಅಪ್ಸ್',
      shuttleRun: 'ಶಟಲ್ ರನ್',
      enduranceRun: 'ಸಹನಶೀಲತೆ ಓಟ',
      
      // Results
      results: 'ಫಲಿತಾಂಶಗಳು',
      analysis: 'ವಿಶ್ಲೇಷಣೆ',
      excellent: 'ಅತ್ಯುತ್ತಮ',
      good: 'ಒಳ್ಳೆಯದು',
      average: 'ಸರಾಸರಿ',
      needsImprovement: 'ಸುಧಾರಣೆ ಅಗತ್ಯ',
      
      // Gamification
      badges: 'ಬ್ಯಾಡ್ಜ್‌ಗಳು',
      streak: 'ದಿನದ ಸರಣಿ',
      points: 'ಅಂಕಗಳು',
      rank: 'ಶ್ರೇಯಾಂಕ',
      achievements: 'ಸಾಧನೆಗಳು',
      
      // Common
      save: 'ಉಳಿಸಿ',
      cancel: 'ರದ್ದುಮಾಡಿ',
      submit: 'ಸಲ್ಲಿಸಿ',
      loading: 'ಲೋಡ್ ಆಗುತ್ತಿದೆ...',
      welcome: 'ಸ್ವಾಗತ',
      getStarted: 'ಪ್ರಾರಂಭಿಸಿ'
    }
  },
  te: {
    translation: {
      // Navigation
      dashboard: 'డాష్‌బోర్డ్',
      profile: 'ప్రొఫైల్',
      tests: 'పరీక్షలు',
      leaderboard: 'లీడర్‌బోర్డ్',
      challenges: 'సవాళ్లు',
      admin: 'అడ్మిన్',
      logout: 'లాగ్ అవుట్',
      
      // Auth
      login: 'లాగిన్',
      register: 'నమోదు',
      email: 'ఇమెయిల్',
      password: 'పాస్‌వర్డ్',
      name: 'పూర్తి పేరు',
      age: 'వయస్సు',
      gender: 'లింగం',
      sport: 'ప్రధాన క్రీడ',
      location: 'స్థలం',
      
      // Tests
      submitTest: 'పరీక్షను సమర్పించండి',
      testInstructions: 'పరీక్ష సూచనలు',
      height: 'ఎత్తు (సెమీ)',
      weight: 'బరువు (కిలోలు)',
      verticalJump: 'నిలువు దూకుడు',
      sitUps: 'సిట్-అప్స్',
      shuttleRun: 'షటిల్ రన్',
      enduranceRun: 'ఓర్పు పరుగు',
      
      // Results
      results: 'ఫలితాలు',
      analysis: 'విశ్లేషణ',
      excellent: 'అద్భుతం',
      good: 'మంచిది',
      average: 'సగటు',
      needsImprovement: 'మెరుగుదల అవసరం',
      
      // Gamification
      badges: 'బ్యాడ్జ్‌లు',
      streak: 'రోజుల వరుస',
      points: 'పాయింట్లు',
      rank: 'ర్యాంక్',
      achievements: 'సాధనలు',
      
      // Common
      save: 'సేవ్ చేయండి',
      cancel: 'రద్దు చేయండి',
      submit: 'సమర్పించండి',
      loading: 'లోడ్ అవుతోంది...',
      welcome: 'స్వాగతం',
      getStarted: 'ప్రారంభించండి'
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: 'en',
    fallbackLng: 'en',
    
    interpolation: {
      escapeValue: false
    }
  });

export default i18n;