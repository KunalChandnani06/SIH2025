import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { User, Edit, Save, X, Trophy, Calendar, MapPin } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

const Profile = () => {
  const { t } = useTranslation();
  const { state, updateProfile } = useAppContext();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: state.user?.name || '',
    age: state.user?.age?.toString() || '',
    gender: state.user?.gender || '',
    sport: state.user?.sport || '',
    location: state.user?.location || '',
  });

  const user = state.user;
  if (!user) return null;

  const handleSave = () => {
    updateProfile({
      name: formData.name,
      age: parseInt(formData.age),
      gender: formData.gender as 'male' | 'female' | 'other',
      sport: formData.sport,
      location: formData.location,
    });
    
    setIsEditing(false);
    toast({
      title: "Profile Updated!",
      description: "Your profile has been successfully updated.",
    });
  };

  const handleCancel = () => {
    setFormData({
      name: user.name,
      age: user.age.toString(),
      gender: user.gender,
      sport: user.sport,
      location: user.location,
    });
    setIsEditing(false);
  };

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">{t('profile')}</h1>
        <Button
          variant={isEditing ? "ghost" : "default"}
          onClick={() => setIsEditing(!isEditing)}
        >
          {isEditing ? <X className="w-4 h-4 mr-2" /> : <Edit className="w-4 h-4 mr-2" />}
          {isEditing ? t('cancel') : 'Edit Profile'}
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Profile Info */}
        <div className="lg:col-span-2">
          <Card className="gradient-card shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                <User className="w-5 h-5 mr-2 text-primary" />
                Personal Information
              </CardTitle>
              <CardDescription>
                Manage your account details and preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="name">{t('name')}</Label>
                  {isEditing ? (
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    />
                  ) : (
                    <div className="p-3 bg-muted rounded-md">{user.name}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="email">Email</Label>
                  <div className="p-3 bg-muted rounded-md text-muted-foreground">
                    {user.email} (Cannot be changed)
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="age">{t('age')}</Label>
                  {isEditing ? (
                    <Input
                      id="age"
                      type="number"
                      value={formData.age}
                      onChange={(e) => setFormData(prev => ({ ...prev, age: e.target.value }))}
                    />
                  ) : (
                    <div className="p-3 bg-muted rounded-md">{user.age} years</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>{t('gender')}</Label>
                  {isEditing ? (
                    <Select 
                      value={formData.gender} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, gender: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="p-3 bg-muted rounded-md capitalize">{user.gender}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label>{t('sport')}</Label>
                  {isEditing ? (
                    <Select 
                      value={formData.sport} 
                      onValueChange={(value) => setFormData(prev => ({ ...prev, sport: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cricket">Cricket</SelectItem>
                        <SelectItem value="football">Football</SelectItem>
                        <SelectItem value="basketball">Basketball</SelectItem>
                        <SelectItem value="tennis">Tennis</SelectItem>
                        <SelectItem value="athletics">Athletics</SelectItem>
                        <SelectItem value="badminton">Badminton</SelectItem>
                        <SelectItem value="swimming">Swimming</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  ) : (
                    <div className="p-3 bg-muted rounded-md capitalize">{user.sport}</div>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="location">{t('location')}</Label>
                  {isEditing ? (
                    <Input
                      id="location"
                      value={formData.location}
                      onChange={(e) => setFormData(prev => ({ ...prev, location: e.target.value }))}
                    />
                  ) : (
                    <div className="p-3 bg-muted rounded-md flex items-center">
                      <MapPin className="w-4 h-4 mr-2 text-muted-foreground" />
                      {user.location}
                    </div>
                  )}
                </div>
              </div>

              {isEditing && (
                <div className="flex space-x-2 pt-4">
                  <Button onClick={handleSave} variant="success">
                    <Save className="w-4 h-4 mr-2" />
                    {t('save')}
                  </Button>
                  <Button onClick={handleCancel} variant="ghost">
                    {t('cancel')}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Stats & Achievements */}
        <div className="space-y-6">
          {/* Quick Stats */}
          <Card className="gradient-card shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Trophy className="w-5 h-5 mr-2 text-primary" />
                Statistics
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Total Points</span>
                <Badge variant="default" className="text-lg px-3 py-1">
                  {user.totalPoints}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Current Streak</span>
                <Badge variant="secondary" className="text-lg px-3 py-1">
                  {user.streak} days
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Badges Earned</span>
                <Badge variant="outline" className="text-lg px-3 py-1">
                  {user.badges.length}
                </Badge>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Member Since</span>
                <div className="text-sm flex items-center">
                  <Calendar className="w-4 h-4 mr-1 text-muted-foreground" />
                  {new Date(user.createdAt).toLocaleDateString()}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Badges */}
          <Card className="gradient-card shadow-card">
            <CardHeader>
              <CardTitle>Recent Badges</CardTitle>
              <CardDescription>Your latest achievements</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-3">
                {['🎯', '🔥', '🏃‍♂️', '💪'].map((emoji, index) => (
                  <div 
                    key={index}
                    className="p-3 rounded-lg text-center gradient-card-hover border border-border/30"
                  >
                    <div className="text-2xl mb-1">{emoji}</div>
                    <div className="text-xs text-muted-foreground">Badge {index + 1}</div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default Profile;