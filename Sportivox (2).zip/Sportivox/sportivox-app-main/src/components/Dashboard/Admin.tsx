import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { 
  Users, 
  Activity, 
  AlertTriangle, 
  Filter,
  Search,
  Download,
  BarChart3,
  Trophy,
  Target,
  Calendar,
  Flag
} from 'lucide-react';
import { mockUsers, mockTestResults } from '@/data/mockData';

const Admin = () => {
  const { t } = useTranslation();
  const { state } = useAppContext();
  const [searchTerm, setSearchTerm] = useState('');
  const [filterSport, setFilterSport] = useState('all');
  const [filterAge, setFilterAge] = useState('all');
  const [selectedTab, setSelectedTab] = useState('athletes');

  // Mock flagged results for demo
  const flaggedResults = mockTestResults.map(result => ({
    ...result,
    flagged: Math.random() > 0.8, // 20% chance of being flagged
    flagReason: Math.random() > 0.5 ? 'Unusual performance spike' : 'Inconsistent form detection'
  })).filter(result => result.flagged);

  const allUsers = mockUsers.filter(user => user.role === 'athlete');
  const allSports = Array.from(new Set(allUsers.map(user => user.sport)));

  // Filter athletes
  const filteredAthletes = allUsers.filter(user => {
    const matchesSearch = user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         user.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesSport = filterSport === 'all' || user.sport === filterSport;
    const matchesAge = filterAge === 'all' || 
                      (filterAge === 'teen' && user.age < 20) ||
                      (filterAge === 'adult' && user.age >= 20 && user.age < 30) ||
                      (filterAge === 'senior' && user.age >= 30);
    
    return matchesSearch && matchesSport && matchesAge;
  });

  // Get stats
  const totalAthletes = allUsers.length;
  const totalTests = mockTestResults.length;
  const totalFlags = flaggedResults.length;
  const activeToday = Math.floor(totalAthletes * 0.3); // Mock active users

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <div className="flex items-center space-x-2">
          <Button size="sm" variant="outline">
            <Download className="w-4 h-4 mr-2" />
            Export Data
          </Button>
        </div>
      </div>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="gradient-card border-primary/20 hover:shadow-primary transition-smooth">
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 mx-auto mb-2 text-primary" />
            <div className="text-2xl font-bold text-primary">{totalAthletes}</div>
            <div className="text-sm text-muted-foreground">Total Athletes</div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-secondary/20 hover:shadow-secondary transition-smooth">
          <CardContent className="p-4 text-center">
            <Activity className="w-8 h-8 mx-auto mb-2 text-secondary" />
            <div className="text-2xl font-bold text-secondary">{totalTests}</div>
            <div className="text-sm text-muted-foreground">Tests Completed</div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-success/20 hover:shadow-success transition-smooth">
          <CardContent className="p-4 text-center">
            <Target className="w-8 h-8 mx-auto mb-2 text-success" />
            <div className="text-2xl font-bold text-success">{activeToday}</div>
            <div className="text-sm text-muted-foreground">Active Today</div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-destructive/20 hover:shadow-destructive transition-smooth">
          <CardContent className="p-4 text-center">
            <AlertTriangle className="w-8 h-8 mx-auto mb-2 text-destructive" />
            <div className="text-2xl font-bold text-destructive">{totalFlags}</div>
            <div className="text-sm text-muted-foreground">Flagged Results</div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="athletes">Athletes</TabsTrigger>
          <TabsTrigger value="results">Test Results</TabsTrigger>
          <TabsTrigger value="flags">Flagged Items</TabsTrigger>
        </TabsList>

        <TabsContent value="athletes" className="space-y-6">
          {/* Filters */}
          <Card className="gradient-card shadow-card">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Filter className="w-5 h-5 mr-2 text-primary" />
                Athlete Filters
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Search</label>
                  <div className="relative">
                    <Search className="w-4 h-4 absolute left-3 top-3 text-muted-foreground" />
                    <Input
                      placeholder="Search athletes..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Sport</label>
                  <Select value={filterSport} onValueChange={setFilterSport}>
                    <SelectTrigger>
                      <SelectValue placeholder="All sports" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Sports</SelectItem>
                      {allSports.map(sport => (
                        <SelectItem key={sport} value={sport}>
                          {sport}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-medium">Age Group</label>
                  <Select value={filterAge} onValueChange={setFilterAge}>
                    <SelectTrigger>
                      <SelectValue placeholder="All ages" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Ages</SelectItem>
                      <SelectItem value="teen">Teen (&lt;20)</SelectItem>
                      <SelectItem value="adult">Adult (20-29)</SelectItem>
                      <SelectItem value="senior">Senior (30+)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex items-end">
                  <Button 
                    variant="ghost" 
                    onClick={() => {
                      setSearchTerm('');
                      setFilterSport('all');
                      setFilterAge('all');
                    }}
                    className="w-full"
                  >
                    Clear Filters
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Athletes List */}
          <Card className="gradient-card shadow-card">
            <CardHeader>
              <CardTitle>Athletes ({filteredAthletes.length})</CardTitle>
              <CardDescription>
                Manage athlete profiles and view their statistics
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredAthletes.map((athlete) => (
                  <div 
                    key={athlete.id}
                    className="flex items-center justify-between p-4 rounded-lg gradient-card-hover border border-border/30 hover:shadow-card transition-smooth"
                  >
                    <div className="flex items-center space-x-4">
                      <Avatar>
                        <AvatarFallback>
                          {athlete.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h4 className="font-semibold">{athlete.name}</h4>
                        <p className="text-sm text-muted-foreground">{athlete.email}</p>
                        <div className="flex items-center space-x-4 text-xs text-muted-foreground mt-1">
                          <span>{athlete.age} years</span>
                          <span>{athlete.sport}</span>
                          <span>{athlete.location}</span>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center space-x-6 text-sm">
                      <div className="text-center">
                        <div className="font-bold text-primary">{athlete.totalPoints}</div>
                        <div className="text-muted-foreground">Points</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-secondary">{athlete.streak}</div>
                        <div className="text-muted-foreground">Streak</div>
                      </div>
                      <div className="text-center">
                        <div className="font-bold text-success">{athlete.badges.length}</div>
                        <div className="text-muted-foreground">Badges</div>
                      </div>
                      <Button size="sm" variant="outline">
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          <Card className="gradient-card shadow-card">
            <CardHeader>
              <CardTitle>Recent Test Results</CardTitle>
              <CardDescription>
                View all test submissions and performance data
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {mockTestResults.map((result) => {
                  const athlete = allUsers.find(u => u.id === result.userId);
                  return (
                    <div 
                      key={result.id}
                      className="flex items-center justify-between p-4 rounded-lg gradient-card-hover border border-border/30"
                    >
                      <div className="flex items-center space-x-4">
                        <Avatar>
                          <AvatarFallback>
                            {athlete?.name.split(' ').map(n => n[0]).join('') || 'U'}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <h4 className="font-semibold">{athlete?.name || 'Unknown'}</h4>
                          <p className="text-sm text-muted-foreground capitalize">
                            {result.testType.replace('_', ' ')}
                          </p>
                          <p className="text-xs text-muted-foreground">
                            {new Date(result.submittedAt).toLocaleString()}
                          </p>
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-center">
                          <div className="text-lg font-bold text-primary">{result.score}</div>
                          <div className="text-xs text-muted-foreground">Score</div>
                        </div>
                        <Badge 
                          variant={result.analysis.grade === 'excellent' ? 'default' : 'secondary'}
                        >
                          {result.analysis.grade.replace('_', ' ')}
                        </Badge>
                        {result.flagged && (
                          <Badge variant="destructive">
                            <Flag className="w-3 h-3 mr-1" />
                            Flagged
                          </Badge>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="flags" className="space-y-6">
          <Card className="gradient-card shadow-card border-destructive/20">
            <CardHeader>
              <CardTitle className="flex items-center">
                <AlertTriangle className="w-5 h-5 mr-2 text-destructive" />
                Flagged Test Results
              </CardTitle>
              <CardDescription>
                Review test results that require manual verification
              </CardDescription>
            </CardHeader>
            <CardContent>
              {flaggedResults.length > 0 ? (
                <div className="space-y-4">
                  {flaggedResults.map((result) => {
                    const athlete = allUsers.find(u => u.id === result.userId);
                    return (
                      <div 
                        key={result.id}
                        className="p-4 rounded-lg border border-destructive/20 bg-destructive/5"
                      >
                        <div className="flex items-center justify-between mb-3">
                          <div className="flex items-center space-x-3">
                            <Avatar>
                              <AvatarFallback>
                                {athlete?.name.split(' ').map(n => n[0]).join('') || 'U'}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <h4 className="font-semibold">{athlete?.name || 'Unknown'}</h4>
                              <p className="text-sm text-muted-foreground capitalize">
                                {result.testType.replace('_', ' ')} • Score: {result.score}
                              </p>
                            </div>
                          </div>
                          <Badge variant="destructive">
                            <Flag className="w-3 h-3 mr-1" />
                            Flagged
                          </Badge>
                        </div>
                        
                        <div className="mb-3">
                          <p className="text-sm font-medium text-destructive">Flag Reason:</p>
                          <p className="text-sm text-muted-foreground">{result.flagReason}</p>
                        </div>

                        <div className="flex space-x-2">
                          <Button size="sm" variant="success">
                            Approve
                          </Button>
                          <Button size="sm" variant="destructive">
                            Reject
                          </Button>
                          <Button size="sm" variant="outline">
                            Review Later
                          </Button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <AlertTriangle className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
                  <h3 className="text-xl font-semibold mb-2">No Flagged Results</h3>
                  <p className="text-muted-foreground">All test results have been verified!</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Admin;