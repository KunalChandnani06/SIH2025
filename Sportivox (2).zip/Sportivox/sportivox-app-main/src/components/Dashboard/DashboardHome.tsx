import { useTranslation } from 'react-i18next';
import { useAppContext } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Trophy, 
  Target, 
  Activity, 
  TrendingUp, 
  Zap,
  Calendar,
  Award,
  BarChart3
} from 'lucide-react';
import { useSpeechSynthesis } from 'react-speech-kit';

const DashboardHome = () => {
  const { t } = useTranslation();
  const { state } = useAppContext();
  const { speak } = useSpeechSynthesis();

  const user = state.user;
  if (!user) return null;

  const weeklyGoal = 300; // points
  const weeklyProgress = (user.totalPoints % weeklyGoal) / weeklyGoal * 100;

  const speakWelcome = () => {
    speak({ 
      text: `Welcome back ${user.name}! You have ${user.totalPoints} points and a ${user.streak} day streak. Keep up the great work!`,
      rate: 0.8,
      pitch: 1.1
    });
  };

  const recentAchievements = [
    { icon: '🎯', title: 'First Test Complete', description: 'Completed your first fitness assessment' },
    { icon: '🔥', title: '7-Day Streak', description: 'Maintained consistent training' },
    { icon: '🏃‍♂️', title: 'Speed Demon', description: 'Excellent shuttle run performance' }
  ];

  const upcomingChallenges = state.challenges.filter(c => !c.completed).slice(0, 3);

  return (
    <div className="space-y-6 animate-slide-up">
      {/* Welcome Section */}
      <div className="gradient-hero rounded-2xl p-8 text-white shadow-primary">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              {t('welcome')}, {user.name}! 👋
            </h1>
            <p className="text-white/80 text-lg">
              Ready to push your limits today?
            </p>
            <Button 
              variant="secondary" 
              className="mt-4"
              onClick={speakWelcome}
            >
              🔊 Hear Your Stats
            </Button>
          </div>
          <div className="text-right">
            <div className="text-4xl font-bold">{user.totalPoints}</div>
            <div className="text-white/80">{t('points')}</div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="gradient-card border-primary/20 hover:shadow-primary transition-smooth">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Trophy className="w-8 h-8 text-primary" />
              <Badge variant="secondary">{t('rank')}</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">#2</div>
            <p className="text-sm text-muted-foreground">In your region</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-secondary/20 hover:shadow-secondary transition-smooth">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Zap className="w-8 h-8 text-secondary" />
              <Badge variant="outline">{t('streak')}</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-secondary">{user.streak}</div>
            <p className="text-sm text-muted-foreground">Days active</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-success/20 hover:shadow-success transition-smooth">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Award className="w-8 h-8 text-success" />
              <Badge variant="outline">{t('badges')}</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-success">{user.badges.length}</div>
            <p className="text-sm text-muted-foreground">Earned</p>
          </CardContent>
        </Card>

        <Card className="gradient-card border-primary/20 hover:shadow-primary transition-smooth">
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <Activity className="w-8 h-8 text-primary" />
              <Badge variant="outline">Tests</Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">12</div>
            <p className="text-sm text-muted-foreground">Completed</p>
          </CardContent>
        </Card>
      </div>

      {/* Progress and Challenges Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Weekly Progress */}
        <Card className="gradient-card shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <BarChart3 className="w-5 h-5 mr-2 text-primary" />
              Weekly Progress
            </CardTitle>
            <CardDescription>
              Your progress towards this week's goal of {weeklyGoal} points
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between text-sm">
                <span>{user.totalPoints % weeklyGoal} points</span>
                <span>{weeklyGoal} points goal</span>
              </div>
              <Progress value={weeklyProgress} className="h-3" />
              <div className="flex items-center justify-between">
                <span className="text-sm text-muted-foreground">
                  {Math.round(weeklyProgress)}% complete
                </span>
                <Button size="sm" variant="sport">
                  <Target className="w-4 h-4 mr-1" />
                  View Details
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Challenges */}
        <Card className="gradient-card shadow-card">
          <CardHeader>
            <CardTitle className="flex items-center">
              <Calendar className="w-5 h-5 mr-2 text-secondary" />
              Active Challenges
            </CardTitle>
            <CardDescription>
              Complete these to earn extra points and badges
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {upcomingChallenges.map((challenge) => (
                <div key={challenge.id} className="flex items-center justify-between p-3 rounded-lg bg-accent/50">
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{challenge.title}</h4>
                    <p className="text-xs text-muted-foreground">{challenge.description}</p>
                    <div className="mt-1">
                      <Progress 
                        value={(challenge.current / challenge.target) * 100} 
                        className="h-1" 
                      />
                    </div>
                  </div>
                  <Badge variant="outline" className="ml-2">
                    {challenge.current}/{challenge.target}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Achievements */}
      <Card className="gradient-card shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Trophy className="w-5 h-5 mr-2 text-success" />
            Recent Achievements
          </CardTitle>
          <CardDescription>
            Your latest accomplishments and milestones
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {recentAchievements.map((achievement, index) => (
              <div 
                key={index}
                className="p-4 rounded-lg gradient-card-hover border border-border/30 hover:shadow-card transition-smooth"
              >
                <div className="text-2xl mb-2">{achievement.icon}</div>
                <h4 className="font-semibold text-sm">{achievement.title}</h4>
                <p className="text-xs text-muted-foreground">{achievement.description}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Button variant="hero" className="h-20 flex-col space-y-2">
          <Activity className="w-6 h-6" />
          <span>Take Test</span>
        </Button>
        <Button variant="sport" className="h-20 flex-col space-y-2">
          <Trophy className="w-6 h-6" />
          <span>Leaderboard</span>
        </Button>
        <Button variant="secondary" className="h-20 flex-col space-y-2">
          <Target className="w-6 h-6" />
          <span>Challenges</span>
        </Button>
        <Button variant="success" className="h-20 flex-col space-y-2">
          <TrendingUp className="w-6 h-6" />
          <span>Progress</span>
        </Button>
      </div>
    </div>
  );
};

export default DashboardHome;