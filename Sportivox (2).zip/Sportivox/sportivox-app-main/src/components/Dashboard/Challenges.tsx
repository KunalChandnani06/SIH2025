import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Target, 
  Calendar, 
  Trophy, 
  Zap,
  Clock,
  Award,
  CheckCircle,
  TrendingUp
} from 'lucide-react';
import { useSpeechSynthesis } from 'react-speech-kit';

const Challenges = () => {
  const { t } = useTranslation();
  const { state } = useAppContext();
  const { speak } = useSpeechSynthesis();
  
  const activeChallenges = state.challenges.filter(c => !c.completed);
  const completedChallenges = state.challenges.filter(c => c.completed);

  const getChallengeIcon = (type: string) => {
    switch (type) {
      case 'daily':
        return Calendar;
      case 'weekly':
        return Target;
      case 'monthly':
        return Trophy;
      default:
        return Zap;
    }
  };

  const getChallengeColor = (type: string) => {
    switch (type) {
      case 'daily':
        return 'text-secondary';
      case 'weekly':
        return 'text-primary';
      case 'monthly':
        return 'text-success';
      default:
        return 'text-muted-foreground';
    }
  };

  const getTimeRemaining = (expiresAt: string) => {
    const now = new Date();
    const expiry = new Date(expiresAt);
    const diff = expiry.getTime() - now.getTime();
    
    if (diff <= 0) return 'Expired';
    
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor((diff % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
    
    if (days > 0) return `${days}d ${hours}h left`;
    return `${hours}h left`;
  };

  const speakChallenge = (challenge: any) => {
    speak({
      text: `${challenge.title}. ${challenge.description}. Progress: ${challenge.current} out of ${challenge.target}. Reward: ${challenge.reward.points} points.`,
      rate: 0.8
    });
  };

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">{t('challenges')}</h1>
        <div className="flex items-center space-x-2">
          <Badge variant="secondary">
            {activeChallenges.length} active
          </Badge>
          <Badge variant="outline">
            {completedChallenges.length} completed
          </Badge>
        </div>
      </div>

      {/* Challenge Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="gradient-card border-secondary/20 hover:shadow-secondary transition-smooth">
          <CardContent className="p-4 text-center">
            <Calendar className="w-8 h-8 mx-auto mb-2 text-secondary" />
            <div className="text-2xl font-bold text-secondary">
              {activeChallenges.filter(c => c.type === 'daily').length}
            </div>
            <div className="text-sm text-muted-foreground">Daily Active</div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-primary/20 hover:shadow-primary transition-smooth">
          <CardContent className="p-4 text-center">
            <Target className="w-8 h-8 mx-auto mb-2 text-primary" />
            <div className="text-2xl font-bold text-primary">
              {activeChallenges.filter(c => c.type === 'weekly').length}
            </div>
            <div className="text-sm text-muted-foreground">Weekly Active</div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-success/20 hover:shadow-success transition-smooth">
          <CardContent className="p-4 text-center">
            <Trophy className="w-8 h-8 mx-auto mb-2 text-success" />
            <div className="text-2xl font-bold text-success">
              {activeChallenges.filter(c => c.type === 'monthly').length}
            </div>
            <div className="text-sm text-muted-foreground">Monthly Active</div>
          </CardContent>
        </Card>

        <Card className="gradient-card border-border/20 hover:shadow-card transition-smooth">
          <CardContent className="p-4 text-center">
            <Award className="w-8 h-8 mx-auto mb-2 text-orange-500" />
            <div className="text-2xl font-bold text-orange-500">
              {state.challenges.reduce((acc, c) => acc + c.reward.points, 0)}
            </div>
            <div className="text-sm text-muted-foreground">Total Rewards</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="active">Active Challenges</TabsTrigger>
          <TabsTrigger value="completed">Completed</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-6">
          {activeChallenges.length > 0 ? (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {activeChallenges.map((challenge) => {
                const Icon = getChallengeIcon(challenge.type);
                const progress = (challenge.current / challenge.target) * 100;
                
                return (
                  <Card key={challenge.id} className="gradient-card shadow-card hover:shadow-primary transition-smooth">
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <Icon className={`w-6 h-6 ${getChallengeColor(challenge.type)}`} />
                          <Badge variant="outline" className="capitalize">
                            {challenge.type}
                          </Badge>
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => speakChallenge(challenge)}
                        >
                          🔊
                        </Button>
                      </div>
                      <CardTitle className="text-lg">{challenge.title}</CardTitle>
                      <CardDescription>{challenge.description}</CardDescription>
                    </CardHeader>
                    
                    <CardContent className="space-y-4">
                      <div className="space-y-2">
                        <div className="flex justify-between text-sm">
                          <span>Progress</span>
                          <span className="font-medium">
                            {challenge.current} / {challenge.target}
                          </span>
                        </div>
                        <Progress value={progress} className="h-3" />
                        <div className="text-xs text-muted-foreground">
                          {Math.round(progress)}% complete
                        </div>
                      </div>

                      <div className="flex items-center justify-between pt-2 border-t">
                        <div className="flex items-center space-x-2 text-sm">
                          <Clock className="w-4 h-4 text-muted-foreground" />
                          <span>{getTimeRemaining(challenge.expiresAt)}</span>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-primary">
                            +{challenge.reward.points}
                          </div>
                          <div className="text-xs text-muted-foreground">Points</div>
                        </div>
                      </div>

                      {challenge.reward.badge && (
                        <div className="p-3 bg-accent/50 rounded-lg">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{challenge.reward.badge.icon}</span>
                            <div>
                              <div className="font-medium text-sm">
                                Bonus: {challenge.reward.badge.name}
                              </div>
                              <div className="text-xs text-muted-foreground">
                                {challenge.reward.badge.description}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <Target className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No Active Challenges</h3>
              <p className="text-muted-foreground">New challenges will appear soon!</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          {completedChallenges.length > 0 ? (
            <div className="space-y-4">
              {completedChallenges.map((challenge) => {
                const Icon = getChallengeIcon(challenge.type);
                
                return (
                  <Card key={challenge.id} className="gradient-card shadow-card border-success/20">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center justify-center w-12 h-12 gradient-success rounded-full">
                            <CheckCircle className="w-6 h-6 text-white" />
                          </div>
                          <div>
                            <h3 className="font-semibold flex items-center space-x-2">
                              <Icon className={`w-4 h-4 ${getChallengeColor(challenge.type)}`} />
                              <span>{challenge.title}</span>
                            </h3>
                            <p className="text-sm text-muted-foreground">
                              {challenge.description}
                            </p>
                            <Badge variant="outline" className="mt-1 capitalize">
                              {challenge.type} • Completed
                            </Badge>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold text-success">
                            +{challenge.reward.points}
                          </div>
                          <div className="text-xs text-muted-foreground">Points Earned</div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-12">
              <Trophy className="w-16 h-16 mx-auto mb-4 text-muted-foreground" />
              <h3 className="text-xl font-semibold mb-2">No Completed Challenges</h3>
              <p className="text-muted-foreground">Complete active challenges to see them here!</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Motivational Section */}
      <Card className="gradient-hero text-white shadow-primary">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-xl font-bold mb-2">Keep Pushing! 💪</h3>
              <p className="text-white/80">
                Every challenge completed brings you closer to your fitness goals.
              </p>
            </div>
            <div className="text-right">
              <TrendingUp className="w-12 h-12 text-white/80" />
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Challenges;