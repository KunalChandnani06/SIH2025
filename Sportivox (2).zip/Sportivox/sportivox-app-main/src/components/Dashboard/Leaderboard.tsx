import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { AnimatedProgress } from '@/components/ui/progress-animated';
import { 
  Trophy, 
  Medal, 
  Award, 
  Crown,
  Filter,
  Users,
  MapPin,
  Zap,
  Radio,
  Square
} from 'lucide-react';
import { mockLeaderboard } from '@/data/mockData';
import { useLiveUpdates } from '@/hooks/useLiveUpdates';

const Leaderboard = () => {
  const { t } = useTranslation();
  const { state } = useAppContext();
  const [filterBySport, setFilterBySport] = useState('all');
  const [filterByLocation, setFilterByLocation] = useState('all');
  const { isLive, toggleLiveUpdates } = useLiveUpdates();

  // Get all unique sports and locations
  const allSports = Array.from(new Set(mockLeaderboard.map(entry => entry.sport)));
  const allLocations = Array.from(new Set(mockLeaderboard.map(entry => entry.location)));

  // Filter leaderboard
  const filteredLeaderboard = mockLeaderboard.filter(entry => {
    const sportMatch = filterBySport === 'all' || entry.sport === filterBySport;
    const locationMatch = filterByLocation === 'all' || entry.location === filterByLocation;
    return sportMatch && locationMatch;
  });

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1:
        return <Crown className="w-6 h-6 text-yellow-500" />;
      case 2:
        return <Medal className="w-6 h-6 text-gray-400" />;
      case 3:
        return <Award className="w-6 h-6 text-amber-600" />;
      default:
        return <span className="w-6 h-6 flex items-center justify-center text-sm font-bold text-muted-foreground">#{rank}</span>;
    }
  };

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1:
        return 'gradient-hero text-white';
      case 2:
        return 'bg-gray-100 text-gray-800';
      case 3:
        return 'bg-amber-50 text-amber-800';
      default:
        return 'gradient-card border-border/30';
    }
  };

  return (
    <div className="space-y-6 animate-slide-up">
      <div className="flex items-center justify-between flex-wrap gap-4">
        <h1 className="text-2xl sm:text-3xl font-bold">{t('leaderboard')}</h1>
        <div className="flex items-center space-x-4">
          <Button
            variant={isLive ? "default" : "outline"}
            size="sm"
            onClick={toggleLiveUpdates}
            className="flex items-center space-x-2"
          >
            {isLive ? <Radio className="w-4 h-4" /> : <Square className="w-4 h-4" />}
            <span className="hidden sm:inline">{isLive ? 'Live Updates ON' : 'Live Updates OFF'}</span>
            <span className="sm:hidden">{isLive ? 'Live' : 'Static'}</span>
          </Button>
          <div className="flex items-center space-x-2 text-sm">
            <Users className="w-4 h-4 sm:w-5 sm:h-5 text-muted-foreground" />
            <span className="text-muted-foreground">
              {filteredLeaderboard.length}
            </span>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card className="gradient-card shadow-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-lg">
            <Filter className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-primary" />
            Filters
          </CardTitle>
          <CardDescription className="text-sm">
            Filter the leaderboard by sport and location
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium">Sport</label>
              <Select value={filterBySport} onValueChange={setFilterBySport}>
                <SelectTrigger className="text-sm">
                  <SelectValue placeholder="All sports" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Sports</SelectItem>
                  {allSports.map(sport => (
                    <SelectItem key={sport} value={sport}>
                      {sport}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium">Location</label>
              <Select value={filterByLocation} onValueChange={setFilterByLocation}>
                <SelectTrigger className="text-sm">
                  <SelectValue placeholder="All locations" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Locations</SelectItem>
                  {allLocations.map(location => (
                    <SelectItem key={location} value={location}>
                      {location}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button 
                variant="ghost" 
                onClick={() => {
                  setFilterBySport('all');
                  setFilterByLocation('all');
                }}
                className="w-full text-sm"
                size="sm"
              >
                Clear Filters
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Top 3 Podium */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
        {filteredLeaderboard.slice(0, 3).map((entry, index) => {
          const actualRank = entry.rank;
          return (
            <Card 
              key={entry.userId} 
              className={`${getRankColor(actualRank)} shadow-card hover:shadow-lg transition-smooth animate-bounce-in ${
                actualRank === 1 ? 'lg:order-2 transform lg:scale-105' : 
                actualRank === 2 ? 'lg:order-1' : 'lg:order-3'
              }`}
            >
              <CardContent className="p-4 sm:p-6 text-center">
                <div className="mb-3 sm:mb-4">
                  {getRankIcon(actualRank)}
                </div>
                <Avatar className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-3 sm:mb-4">
                  <AvatarFallback className="text-sm sm:text-lg font-bold">
                    {entry.name.split(' ').map(n => n[0]).join('')}
                  </AvatarFallback>
                </Avatar>
                <h3 className="font-bold text-base sm:text-lg mb-1">{entry.name}</h3>
                <div className="flex items-center justify-center text-xs sm:text-sm text-muted-foreground mb-2">
                  <MapPin className="w-3 h-3 mr-1" />
                  {entry.location}
                </div>
                <Badge variant="outline" className="mb-3 text-xs">
                  {entry.sport}
                </Badge>
                <div className="space-y-2">
                  <div className="text-xl sm:text-2xl font-bold text-primary">
                    {entry.totalPoints.toLocaleString()}
                  </div>
                  <div className="text-xs text-muted-foreground">Points</div>
                  <div className="flex justify-center space-x-3 sm:space-x-4 text-xs">
                    <div className="flex items-center">
                      <Trophy className="w-3 h-3 mr-1 text-success" />
                      {entry.badges}
                    </div>
                    <div className="flex items-center">
                      <Zap className="w-3 h-3 mr-1 text-secondary" />
                      {entry.streak}d
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Full Leaderboard */}
      <Card className="gradient-card shadow-card">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center text-lg">
            <Trophy className="w-4 h-4 sm:w-5 sm:h-5 mr-2 text-primary" />
            Complete Rankings
          </CardTitle>
          <CardDescription className="text-sm">
            Full leaderboard with detailed statistics
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 sm:space-y-3">
            {filteredLeaderboard.map((entry) => {
              const isCurrentUser = entry.userId === state.user?.id;
              
              return (
                <div 
                  key={entry.userId}
                  className={`flex items-center justify-between p-3 sm:p-4 rounded-lg transition-smooth ${
                    isCurrentUser 
                      ? 'gradient-primary text-white shadow-primary' 
                      : 'gradient-card-hover border border-border/30 hover:shadow-card'
                  }`}
                >
                  <div className="flex items-center space-x-2 sm:space-x-4 flex-1 min-w-0">
                    <div className="flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 flex-shrink-0">
                      {getRankIcon(entry.rank)}
                    </div>
                    <Avatar className="w-8 h-8 sm:w-10 sm:h-10 flex-shrink-0">
                      <AvatarFallback className="text-xs sm:text-sm">
                        {entry.name.split(' ').map(n => n[0]).join('')}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2">
                        <h4 className="font-semibold text-sm sm:text-base truncate">{entry.name}</h4>
                        {isCurrentUser && (
                          <Badge variant="secondary" className="text-xs flex-shrink-0">
                            You
                          </Badge>
                        )}
                      </div>
                      <div className="flex items-center space-x-2 sm:space-x-4 text-xs sm:text-sm opacity-80">
                        <span className="truncate">{entry.sport}</span>
                        <span className="flex items-center flex-shrink-0">
                          <MapPin className="w-3 h-3 mr-1" />
                          <span className="hidden sm:inline">{entry.location}</span>
                          <span className="sm:hidden">{entry.location.slice(0, 3)}</span>
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2 sm:space-x-6 text-xs sm:text-sm flex-shrink-0">
                    <div className="text-center">
                      <div className="font-bold text-sm sm:text-lg">
                        {entry.totalPoints > 999 ? `${(entry.totalPoints / 1000).toFixed(1)}k` : entry.totalPoints.toLocaleString()}
                      </div>
                      <div className="opacity-70 text-xs hidden sm:block">Points</div>
                    </div>
                    <div className="text-center hidden sm:block">
                      <div className="font-bold text-lg">{entry.badges}</div>
                      <div className="opacity-70">Badges</div>
                    </div>
                    <div className="text-center">
                      <div className="font-bold text-sm sm:text-lg">{entry.streak}</div>
                      <div className="opacity-70 text-xs hidden sm:block">Streak</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Your Position */}
      {state.user && (
        <Card className="gradient-primary text-white shadow-primary animate-pulse-glow">
          <CardContent className="p-3 sm:p-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="font-semibold text-sm sm:text-base">Your Current Position</h3>
                <p className="text-white/80 text-xs sm:text-sm">Keep training to climb higher!</p>
              </div>
              <div className="text-right">
                <div className="text-xl sm:text-2xl font-bold">#2</div>
                <div className="text-white/80 text-xs sm:text-sm">of {filteredLeaderboard.length}</div>
              </div>
            </div>
            <div className="mt-3">
              <div className="flex justify-between text-xs mb-1">
                <span>Progress to #1</span>
                <span>78%</span>
              </div>
              <AnimatedProgress value={78} className="h-2" color="secondary" />
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default Leaderboard;