import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { useAppContext } from '@/context/AppContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { AnimatedProgress } from '@/components/ui/progress-animated';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { 
  Activity, 
  Play, 
  Upload, 
  Timer, 
  Ruler, 
  Target,
  TrendingUp,
  Award,
  Volume2
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { useSpeechSynthesis } from 'react-speech-kit';

const Tests = () => {
  const { t } = useTranslation();
  const { state, submitTestResult, analyzeVideo } = useAppContext();
  const { speak } = useSpeechSynthesis();
  const [selectedTest, setSelectedTest] = useState<string | null>(null);
  const [testData, setTestData] = useState<Record<string, any>>({});
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showResults, setShowResults] = useState(false);
  const [analysisResults, setAnalysisResults] = useState<any>(null);

  const fitnessTests = [
    {
      id: 'height_weight',
      name: 'Height & Weight',
      description: 'Basic anthropometric measurements',
      icon: Ruler,
      color: 'text-primary',
      instructions: 'Measure your height in centimeters and weight in kilograms. Ensure accurate measurements for proper assessment.',
      fields: [
        { key: 'height', label: 'Height (cm)', type: 'number', min: 100, max: 250 },
        { key: 'weight', label: 'Weight (kg)', type: 'number', min: 30, max: 200 }
      ]
    },
    {
      id: 'vertical_jump',
      name: 'Vertical Jump',
      description: 'Measures explosive leg power',
      icon: TrendingUp,
      color: 'text-secondary',
      instructions: 'Stand with feet shoulder-width apart. Jump as high as possible with arms reaching up. Measure the height reached.',
      fields: [
        { key: 'height', label: 'Jump Height (cm)', type: 'number', min: 10, max: 100 },
        { key: 'attempts', label: 'Number of Attempts', type: 'number', min: 1, max: 5, default: 3 }
      ]
    },
    {
      id: 'sit_ups',
      name: 'Sit-ups',
      description: 'Tests core strength and endurance',
      icon: Activity,
      color: 'text-success',
      instructions: 'Lie on your back, knees bent, feet flat. Perform as many sit-ups as possible in 60 seconds.',
      fields: [
        { key: 'count', label: 'Number of Sit-ups', type: 'number', min: 0, max: 100 },
        { key: 'duration', label: 'Duration (seconds)', type: 'number', min: 30, max: 120, default: 60 }
      ]
    },
    {
      id: 'shuttle_run',
      name: 'Shuttle Run',
      description: 'Measures agility and speed',
      icon: Timer,
      color: 'text-orange-500',
      instructions: 'Run between two markers 20 meters apart as fast as possible. Record your best time.',
      fields: [
        { key: 'time', label: 'Time (seconds)', type: 'number', step: 0.1, min: 5, max: 30 },
        { key: 'distance', label: 'Distance (meters)', type: 'number', default: 20, min: 10, max: 50 }
      ]
    },
    {
      id: 'endurance_run',
      name: 'Endurance Run',
      description: 'Tests cardiovascular fitness',
      icon: Target,
      color: 'text-purple-500',
      instructions: 'Run continuously for the specified distance or time. Maintain steady pace throughout.',
      fields: [
        { key: 'distance', label: 'Distance (meters)', type: 'number', default: 1000, min: 500, max: 5000 },
        { key: 'time', label: 'Time (minutes)', type: 'number', step: 0.1, min: 2, max: 30 }
      ]
    }
  ];

  const handleTestSubmit = async () => {
    if (!selectedTest) return;

    setIsAnalyzing(true);
    
    try {
      // Simulate AI analysis
      const analysis = await analyzeVideo(selectedTest, testData);
      
      // Calculate score based on test type and data
      let score = 0;
      let grade: 'excellent' | 'good' | 'average' | 'needs_improvement' = 'average';
      
      switch (selectedTest) {
        case 'vertical_jump':
          score = Math.min(100, (testData.height / 70) * 100);
          break;
        case 'sit_ups':
          score = Math.min(100, (testData.count / 50) * 100);
          break;
        case 'shuttle_run':
          score = Math.min(100, Math.max(0, 100 - ((testData.time - 8) * 10)));
          break;
        case 'endurance_run':
          const pace = testData.time / (testData.distance / 1000); // min/km
          score = Math.min(100, Math.max(0, 100 - ((pace - 4) * 15)));
          break;
        default:
          score = 75;
      }

      if (score >= 90) grade = 'excellent';
      else if (score >= 75) grade = 'good';
      else if (score >= 60) grade = 'average';
      else grade = 'needs_improvement';

      const testResult = {
        userId: state.user!.id,
        testType: selectedTest as any,
        data: testData,
        score: Math.round(score),
        analysis: {
          score: Math.round(score),
          grade,
          feedback: `${grade === 'excellent' ? 'Outstanding' : grade === 'good' ? 'Good' : grade === 'average' ? 'Average' : 'Keep practicing'} performance!`,
          improvements: ['Focus on technique', 'Increase training frequency'],
          benchmark: {
            percentile: Math.round(score),
            ageGroup: `${Math.floor(state.user!.age / 5) * 5}-${Math.floor(state.user!.age / 5) * 5 + 4}`,
            gender: state.user!.gender
          }
        },
        flagged: false
      };

      submitTestResult(testResult);
      setAnalysisResults(testResult.analysis);
      setShowResults(true);
      
      toast({
        title: "Test Completed!",
        description: `You scored ${Math.round(score)} points. Great work!`,
      });

      // Text-to-speech feedback
      speak({
        text: `Test completed! You scored ${Math.round(score)} points with ${grade} performance. ${testResult.analysis.feedback}`,
        rate: 0.8
      });

    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to analyze test results. Please try again.",
        variant: "destructive"
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const speakInstructions = (instructions: string) => {
    speak({ text: instructions, rate: 0.8 });
  };

  const resetTest = () => {
    setSelectedTest(null);
    setTestData({});
    setShowResults(false);
    setAnalysisResults(null);
  };

  return (
      <div className="space-y-4 sm:space-y-6">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <h1 className="text-2xl sm:text-3xl font-bold">{t('tests')}</h1>
          <Badge variant="secondary" className="text-xs sm:text-sm">
            {state.testResults.length} tests completed
          </Badge>
        </div>

        <Tabs defaultValue="available" className="w-full">
          <TabsList className="grid w-full grid-cols-2 h-auto">
            <TabsTrigger value="available" className="text-sm">Available Tests</TabsTrigger>
            <TabsTrigger value="history" className="text-sm">Test History</TabsTrigger>
          </TabsList>

        <TabsContent value="available" className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
            {fitnessTests.map((test) => {
              const Icon = test.icon;
              return (
                <Card key={test.id} className="gradient-card shadow-card hover:shadow-primary transition-smooth animate-bounce-in">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <Icon className={`w-6 h-6 sm:w-8 sm:h-8 ${test.color}`} />
                      <Button 
                        size="sm" 
                        variant="ghost"
                        onClick={() => speakInstructions(test.instructions)}
                        className="p-1 sm:p-2"
                        title="Read instructions aloud"
                      >
                        <Volume2 className="w-3 h-3 sm:w-4 sm:h-4" />
                      </Button>
                    </div>
                    <CardTitle className="text-base sm:text-lg">{test.name}</CardTitle>
                    <CardDescription className="text-sm">{test.description}</CardDescription>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button 
                          className="w-full" 
                          variant="sport"
                          onClick={() => setSelectedTest(test.id)}
                          size="sm"
                        >
                          <Play className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                          Start Test
                        </Button>
                      </DialogTrigger>
                      <DialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[90vh] overflow-y-auto">
                        <DialogHeader>
                          <DialogTitle className="flex items-center text-lg">
                            <Icon className={`w-5 h-5 sm:w-6 sm:h-6 mr-2 ${test.color}`} />
                            {test.name}
                          </DialogTitle>
                          <DialogDescription className="text-sm">
                            {test.instructions}
                          </DialogDescription>
                        </DialogHeader>

                        {!showResults ? (
                          <div className="space-y-4">
                            <div className="flex justify-between items-center">
                              <h3 className="font-semibold text-sm sm:text-base">Test Data</h3>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => speakInstructions(test.instructions)}
                                className="text-xs sm:text-sm"
                              >
                                <Volume2 className="w-3 h-3 sm:w-4 sm:h-4 mr-1" />
                                <span className="hidden sm:inline">Read Instructions</span>
                                <span className="sm:hidden">Read</span>
                              </Button>
                            </div>

                            <div className="grid grid-cols-1 gap-3 sm:gap-4">
                              {test.fields.map((field) => (
                                <div key={field.key} className="space-y-2">
                                  <Label htmlFor={field.key} className="text-sm">{field.label}</Label>
                                  <Input
                                    id={field.key}
                                    type={field.type}
                                    step={field.step}
                                    min={field.min}
                                    max={field.max}
                                    value={testData[field.key] || field.default || ''}
                                    onChange={(e) => setTestData(prev => ({
                                      ...prev,
                                      [field.key]: field.type === 'number' ? parseFloat(e.target.value) || 0 : e.target.value
                                    }))}
                                    placeholder={`Enter ${field.label.toLowerCase()}`}
                                    className="text-sm sm:text-base"
                                  />
                                </div>
                              ))}
                            </div>

                            <div className="flex flex-col sm:flex-row space-y-2 sm:space-y-0 sm:space-x-2 pt-4">
                              <Button 
                                onClick={handleTestSubmit}
                                disabled={isAnalyzing}
                                variant="success"
                                className="flex-1 text-sm sm:text-base"
                                size="sm"
                              >
                                {isAnalyzing ? (
                                  <>
                                    <Upload className="w-3 h-3 sm:w-4 sm:h-4 mr-2 animate-spin" />
                                    Analyzing...
                                  </>
                                ) : (
                                  <>
                                    <Upload className="w-3 h-3 sm:w-4 sm:h-4 mr-2" />
                                    Submit Test
                                  </>
                                )}
                              </Button>
                              <Button variant="ghost" onClick={resetTest} size="sm">
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : (
                          <div className="space-y-4">
                            <div className="text-center p-4 sm:p-6 gradient-card-hover rounded-lg animate-bounce-in">
                              <Award className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 text-success animate-pulse-glow" />
                              <h3 className="text-xl sm:text-2xl font-bold mb-2">Test Complete!</h3>
                              <div className="text-3xl sm:text-4xl font-bold text-primary mb-2">
                                {analysisResults.score}/100
                              </div>
                              <Badge 
                                variant={analysisResults.grade === 'excellent' ? 'default' : 'secondary'}
                                className="text-sm sm:text-lg px-3 sm:px-4 py-1"
                              >
                                {analysisResults.grade.replace('_', ' ').toUpperCase()}
                              </Badge>
                            </div>

                            <div className="space-y-3">
                              <div>
                                <h4 className="font-semibold mb-2 text-sm sm:text-base">Feedback</h4>
                                <p className="text-muted-foreground text-sm">{analysisResults.feedback}</p>
                              </div>
                              
                              <div>
                                <h4 className="font-semibold mb-2 text-sm sm:text-base">Benchmark</h4>
                                <p className="text-sm text-muted-foreground">
                                  {analysisResults.benchmark.percentile}th percentile for {analysisResults.benchmark.gender} athletes aged {analysisResults.benchmark.ageGroup}
                                </p>
                              </div>
                            </div>

                            <Button onClick={resetTest} className="w-full" variant="hero" size="sm">
                              Take Another Test
                            </Button>
                          </div>
                        )}
                      </DialogContent>
                    </Dialog>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <div className="space-y-3 sm:space-y-4">
            {state.testResults.length > 0 ? (
              state.testResults.map((result) => (
                <Card key={result.id} className="gradient-card shadow-card animate-slide-up">
                  <CardContent className="p-4 sm:p-6">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold capitalize text-sm sm:text-base">
                          {result.testType.replace('_', ' ')}
                        </h3>
                        <p className="text-xs sm:text-sm text-muted-foreground">
                          {new Date(result.submittedAt).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <div className="text-xl sm:text-2xl font-bold text-primary">
                          {result.score}
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {result.analysis.grade.replace('_', ' ')}
                        </Badge>
                      </div>
                    </div>
                    <div className="mt-3">
                      <AnimatedProgress 
                        value={result.score} 
                        className="h-2" 
                        color={result.score >= 80 ? 'success' : result.score >= 60 ? 'primary' : 'secondary'} 
                      />
                    </div>
                  </CardContent>
                </Card>
              ))
            ) : (
              <div className="text-center py-12">
                <Activity className="w-12 h-12 sm:w-16 sm:h-16 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-lg sm:text-xl font-semibold mb-2">No tests completed yet</h3>
                <p className="text-muted-foreground text-sm">Take your first fitness test to get started!</p>
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Tests;