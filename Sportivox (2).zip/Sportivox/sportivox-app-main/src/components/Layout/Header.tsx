import { useState } from 'react';
import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/AppContext';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Globe, User, LogOut, Trophy, Target, BarChart3 } from 'lucide-react';

const Header = () => {
  const { t, i18n } = useTranslation();
  const { state, logout } = useAppContext();
  const [currentLanguage, setCurrentLanguage] = useState(i18n.language);

  const languages = [
    { code: 'en', name: 'English', flag: '🇺🇸' },
    { code: 'hi', name: 'हिंदी', flag: '🇮🇳' },
    { code: 'ta', name: 'தமிழ்', flag: '🇮🇳' },
    { code: 'kn', name: 'ಕನ್ನಡ', flag: '🇮🇳' },
    { code: 'te', name: 'తెలుగు', flag: '🇮🇳' },
  ];

  const changeLanguage = (langCode: string) => {
    i18n.changeLanguage(langCode);
    setCurrentLanguage(langCode);
    localStorage.setItem('sports_assess_language', langCode);
  };

  const handleLogout = () => {
    logout();
    window.location.href = '/';
  };

  if (!state.user) return null;

  return (
    <header className="gradient-card border-b border-border/50 shadow-card sticky top-0 z-50 backdrop-blur-sm">
      <div className="container mx-auto px-2 sm:px-4 py-2 sm:py-3">
        <div className="flex items-center justify-between">
          {/* Logo and Brand */}
          <div className="flex items-center space-x-2 sm:space-x-3">
            <div className="gradient-primary w-8 h-8 sm:w-10 sm:h-10 rounded-xl flex items-center justify-center shadow-primary">
              <Trophy className="w-4 h-4 sm:w-6 sm:h-6 text-white" />
            </div>
            <div>
              <h1 className="text-lg sm:text-xl font-bold text-foreground">SportAssess</h1>
              <p className="text-xs text-muted-foreground hidden sm:block">AI-Powered Sports Assessment</p>
            </div>
          </div>

          {/* User Stats - Hidden on very small screens */}
          <div className="hidden lg:flex items-center space-x-6">
            <div className="flex items-center space-x-2 text-sm">
              <Target className="w-4 h-4 text-primary" />
              <span className="font-medium">{state.user.totalPoints}</span>
              <span className="text-muted-foreground hidden xl:inline">{t('points')}</span>
            </div>
            <div className="flex items-center space-x-2 text-sm">
              <BarChart3 className="w-4 h-4 text-secondary" />
              <span className="font-medium">{state.user.streak}</span>
              <span className="text-muted-foreground hidden xl:inline">{t('streak')}</span>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center space-x-1 sm:space-x-2">
            {/* Language Selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="px-2 sm:px-3">
                  <Globe className="w-4 h-4" />
                  <span className="ml-1 hidden sm:inline">{languages.find(l => l.code === currentLanguage)?.flag}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-44">
                {languages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    onClick={() => changeLanguage(lang.code)}
                    className={currentLanguage === lang.code ? 'bg-accent' : ''}
                  >
                    <span className="mr-2">{lang.flag}</span>
                    <span className="text-sm">{lang.name}</span>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Menu */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="px-2 sm:px-3">
                  <User className="w-4 h-4" />
                  <span className="ml-1 sm:ml-2 hidden md:inline max-w-[100px] truncate">{state.user.name}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-48">
                {/* Mobile-only stats */}
                <div className="lg:hidden border-b border-border pb-2 mb-2">
                  <div className="px-2 py-1 text-sm space-y-1">
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">{t('points')}</span>
                      <span className="font-medium">{state.user.totalPoints}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-muted-foreground">{t('streak')}</span>
                      <span className="font-medium">{state.user.streak}</span>
                    </div>
                  </div>
                </div>
                <DropdownMenuItem onClick={handleLogout}>
                  <LogOut className="w-4 h-4 mr-2" />
                  {t('logout')}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;