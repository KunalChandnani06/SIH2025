import { useTranslation } from 'react-i18next';
import { Button } from '@/components/ui/button';
import { useAppContext } from '@/context/AppContext';
import { 
  Home, 
  User, 
  Activity, 
  Trophy, 
  Target,
  Settings
} from 'lucide-react';

interface NavigationProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const Navigation = ({ activeTab, onTabChange }: NavigationProps) => {
  const { t } = useTranslation();
  const { state } = useAppContext();

  const navItems = [
    { id: 'dashboard', label: t('dashboard'), icon: Home },
    { id: 'profile', label: t('profile'), icon: User },
    { id: 'tests', label: t('tests'), icon: Activity },
    { id: 'leaderboard', label: t('leaderboard'), icon: Trophy },
    { id: 'challenges', label: t('challenges'), icon: Target },
  ];

  // Add admin tab for admin users
  if (state.user?.role === 'admin') {
    navItems.push({ id: 'admin', label: t('admin'), icon: Settings });
  }

  return (
    <nav className="gradient-card border-r border-border/50 w-64 min-h-screen p-4 shadow-card">
      <div className="space-y-2">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <Button
              key={item.id}
              variant={isActive ? "default" : "ghost"}
              className={`w-full justify-start ${
                isActive 
                  ? "gradient-primary text-white shadow-primary" 
                  : "hover:bg-accent/50"
              }`}
              onClick={() => onTabChange(item.id)}
            >
              <Icon className="w-5 h-5 mr-3" />
              {item.label}
            </Button>
          );
        })}
      </div>

      {/* User Quick Stats */}
      <div className="mt-8 p-4 gradient-card-hover rounded-lg border border-border/30">
        <h3 className="font-semibold text-sm text-muted-foreground mb-3">Quick Stats</h3>
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm">Points</span>
            <span className="font-bold text-primary">{state.user?.totalPoints || 0}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm">Streak</span>
            <span className="font-bold text-secondary">{state.user?.streak || 0} days</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-sm">Badges</span>
            <span className="font-bold text-success">{state.user?.badges?.length || 0}</span>
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;